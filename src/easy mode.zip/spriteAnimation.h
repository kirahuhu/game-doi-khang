#ifndef SPRITE_ANIMATION_H
#define SPRITE_ANIMATION_H

#include <SFML/Graphics.hpp>
#include <vector>

class SpriteAnimation {
private:
    sf::Texture* spriteSheet;
    std::vector<sf::IntRect> frames;
    float frameTime;
    float timer;
    int currentFrame;

public:
    SpriteAnimation();

    void setSpriteSheet(sf::Texture* tex);
    void addFrame(sf::IntRect rect);
    void update(float deltaTime);
    void applyToSprite(sf::Sprite& sprite);
    void reset();
};

#endif
