#include "SpriteAnimation.h"

SpriteAnimation::SpriteAnimation() : spriteSheet(nullptr), frameTime(0.1f), timer(0.f), currentFrame(0) {}

void SpriteAnimation::setSpriteSheet(sf::Texture* tex) {
    spriteSheet = tex;
}

void SpriteAnimation::addFrame(sf::IntRect rect) {
    frames.push_back(rect);
}

void SpriteAnimation::update(float deltaTime) {
    if (frames.empty()) return;

    timer += deltaTime;
    if (timer >= frameTime) {
        timer = 0.f;
        currentFrame = (currentFrame + 1) % frames.size();
    }
}

void SpriteAnimation::applyToSprite(sf::Sprite& sprite) {
    if (spriteSheet)
        sprite.setTexture(*spriteSheet);
    if (!frames.empty())
        sprite.setTextureRect(frames[currentFrame]);
}

void SpriteAnimation::reset() {
    currentFrame = 0;
    timer = 0.f;
}
