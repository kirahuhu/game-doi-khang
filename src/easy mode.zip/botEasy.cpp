#include "BotEasy.h"

BotEasy::BotEasy() {
    spriteSheet.loadFromFile("assets/boteasy_spritesheet.png");

    idleAnim.setSpriteSheet(&spriteSheet);
    for (int i = 0; i < 10; ++i) {
        idleAnim.addFrame(sf::IntRect(i * 96, 0 * 96, 96, 96));
    }

    punchAnim.setSpriteSheet(&spriteSheet);
    for (int i = 0; i < 6; ++i) {
        punchAnim.addFrame(sf::IntRect(i * 96, 3 * 96, 96, 96));
    }

    currentAnim = &idleAnim;
    sprite.setScale(2.0f, 2.0f); // Phóng to

    position = sf::Vector2f(200, 300);
    speed = 100.0f;
}

void BotEasy::update(float dt) {
    currentAnim->update(dt);
    currentAnim->applyToSprite(sprite);

    sprite.setPosition(position);
}

void BotEasy::draw(sf::RenderWindow& window) {
    window.draw(sprite);
}

void BotEasy::moveLeft() {
    position.x -= speed * 0.016f;
    currentAnim = &idleAnim;
}

void BotEasy::moveRight() {
    position.x += speed * 0.016f;
    currentAnim = &idleAnim;
}

void BotEasy::punch() {
    currentAnim = &punchAnim;
    punchAnim.reset();
}
