#ifndef BOTEASY_H
#define BOTEASY_H

#include <SFML/Graphics.hpp>
#include "SpriteAnimation.h"

class BotEasy {
private:
    sf::Sprite sprite;
    sf::Texture spriteSheet;

    SpriteAnimation idleAnim;
    SpriteAnimation punchAnim;
    SpriteAnimation* currentAnim;

    sf::Vector2f position;
    float speed;

public:
    BotEasy();
    void update(float deltaTime);
    void draw(sf::RenderWindow& window);
    void moveLeft();
    void moveRight();
    void punch();
};

#endif
